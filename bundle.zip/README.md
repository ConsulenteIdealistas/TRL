﻿# TRL投資分析システム (v0.1.0)

技術・企業の**長期成長評価**と、1〜6か月の**イベント評価**を分離して扱う分析基盤。
根拠・出典・不足情報を保存し、情報不足の候補は**保留(hold)**してレビューキューに入れます。
外部ライブラリ不要(Python標準ライブラリのみ)。スマホのブラウザだけでセットアップ・運用できます。

> スコアは評価尺度です。株価上昇確率・成功確率・投資利益率ではなく、売買の自動判定にも使えません。

## スマホだけでのセットアップ(約10分・無料)

1. GitHub(Safari)で **New repository** を作成(Private推奨。Actionsは無料枠あり)。
2. **Settings → Actions → General → Workflow permissions** を **Read and write permissions** にして保存。
3. リポジトリの **Add file → Upload files** で `bundle.zip`(このzipの中身を入れたもの。配布された `bundle.zip` をそのまま)をアップロードして Commit。
4. **Add file → Create new file** → ファイル名欄に `.github/workflows/main.yml` と入力(スラッシュで自動的にフォルダになります)→ 配布された `main.yml` の中身を貼り付けて Commit。
5. **Actions** タブ → **TRL pipeline** → **Run workflow**。
   初回は `bundle.zip` を展開してリポジトリへコミットし、テスト → 収集 → 保存まで実行します。

### 結果の見方
- 実行ページの **Summary** にレポートが表示されます。
- `data` ブランチの `reports/latest.md` でも読めます(GitHubアプリ可)。
- 評価結果・レビューキュー・実行履歴は `data` ブランチの `trl.sqlite` に永続化されます。

### AI評価を有効にする(任意)
既定では **LLM未設定 = 収集・重複排除・スクリーニングのみ**で、評価は行いません(課金を避けるため)。
**Settings → Secrets and variables → Actions** で設定:

| 種別 | 名前 | 値 |
|---|---|---|
| Variable | `TRL_LLM_PROVIDER` | `gemini` または `anthropic` |
| Secret | `GEMINI_API_KEY` または `ANTHROPIC_API_KEY` | APIキー |
| Variable(任意) | `TRL_LLM_MODEL` | モデル名 |
| Secret(任意) | `NCBI_API_KEY` | PubMedのレート制限緩和 |

- Gemini には無料枠がありますが、**条件・上限は各自で確認してください**(未検証)。Anthropic APIは従量課金です。
- 1回の評価件数は `max_eval`(既定10)で制限します。キーはSecretsにのみ置き、ログではマスクされます。

## 定期実行
`.github/workflows/main.yml` の `cron` で設定(既定: 毎週月曜 21:17 UTC)。変更はスマホのGitHubからファイル編集で可能。

## 設定(`config/`)
- `scoring.json`: 配点・必須項目・スコア帯・スクリーニング条件・プロンプト版。**変更時は `config_version` を更新**(実行・評価ごとに版とハッシュを記録)。
- `sources.json`: 検索クエリ。テーマの追加・変更はここだけ。
- `prompts/*.vN.md`: プロンプト。変更は新しい版ファイル(例 `long.v2.md`)を作り `scoring.json` の `prompts` を切替。

## 設計メモ
- 総合点は6項目すべてが非nullのときのみ確定。1つでも null なら **hold**(重みの再配分はしない)。必須項目(長期: 技術成熟度・収益化、イベント: カタリスト・市場予想乖離・未織り込み度)の欠落は理由に明記。
- 長期とイベントは別々に評価・保存し、平均しない。
- イベント評価は、市場予想が確認できなければ分類を確定せず乖離・織り込み度を保留に強制。
- 重複排除は DOI / PMID / arXiv ID / URL のみ。タイトル類似では統合しない。
- 評価は基準日(`--as-of`)以前の資料のみ対象(それ以降の公開は除外)。
- 保存: `data`ブランチに**単一コミットで強制上書き**(履歴肥大を避ける代わりに、DBの過去版は残らない)。同時実行は `concurrency` で直列化。
- 失敗した情報源は実行ログの `::warning::` とレポートに表示。全情報源が失敗した場合のみジョブが失敗。

## ローカル/CLI
```
python -m unittest discover -s tests -t .
python -m trl run --data-dir data --sources arxiv --llm gemini
python -m trl queue --data-dir data
```

## 実装状況(正直な記録)
**実装・テスト済み(自動テスト44件)**: 設定検証、採点・hold・スコア帯、日付/鮮度、正規化、重複排除、保存/再読込、レビューキュー、プロンプト差し込み、不正AI応答の検出、HTTPリトライ/秘密情報マスク、PubMed/arXivのXML解析(固定サンプル)、収集→評価→保存の統合(モックAI)。

**未検証**: 実際のPubMed/arXiv API、Gemini/Anthropic API(応答形式・モデル名・無料枠)、GitHub Actions上の実行(ワークフローは未実行)、`data` ブランチへの保存。初回実行で不具合が出る可能性があります。

**未実装**: 臨床試験・特許・IR・市場データ連携、需給分析、TRL9相当からの成長余地探索、過去イベントの事後検証、プロンプト自動最適化。評価精度(AIの採点の妥当性)の検証。
