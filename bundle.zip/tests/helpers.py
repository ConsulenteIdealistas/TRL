import json
from datetime import date

from trl.config import load_config

CFG = load_config()
AS_OF = date(2026, 10, 20)
LONG_KEYS = list(CFG["scoring"]["long"]["weights"])
EVENT_KEYS = list(CFG["scoring"]["event"]["weights"])
ABSTRACT = "This study reports a new battery electrolyte with improved stability and cycle life. " * 4


def raw(source="arxiv", sid="2610.00001", title="Paper A", doi=None, published="2026-10-10", abstract=ABSTRACT, **kw):
    d = {"source": source, "source_id": sid, "title": title, "abstract": abstract, "doi": doi,
         "published": published, "url": f"https://example.org/{sid}", "fields": ["x"]}
    if source == "arxiv":
        d["arxiv_id"] = sid
    if source == "pubmed":
        d["pmid"] = sid
    d.update(kw)
    return d


def item(score, with_evidence=True):
    if score is None:
        return {"score": None, "reason": "", "evidence": [], "counter_evidence": [], "missing_info": ["情報不足"]}
    return {"score": score, "reason": "理由", "evidence": [{"ref": "https://example.org/x", "summary": "要約", "kind": "fact"}] if with_evidence else [],
            "counter_evidence": ["反証"], "missing_info": []}


def assessment(keys, scores=None, event=None):
    scores = scores or {}
    obj = {"items": {k: item(scores.get(k, 70)) for k in keys}, "next_sources": ["IR"], "reeval_conditions": ["決算後"]}
    if event is not None:
        obj["event"] = event
    return obj


EXTRACTION = {"facts": [{"statement": "f", "source": "u"}], "inferences": [], "forecasts": [], "hypotheses": [],
              "counter_points": [], "missing_info": []}


def make_llm_fn(long_scores=None, event=None, event_scores=None, bad=None):
    def fn(prompt):
        if "根拠抽出」担当" in prompt:
            return json.dumps(EXTRACTION)
        if "長期成長評価」担当" in prompt:
            if bad:
                return bad
            return json.dumps(assessment(LONG_KEYS, long_scores))
        if "イベント評価」担当" in prompt:
            return json.dumps(assessment(EVENT_KEYS, event_scores, event or {"classification": 2, "market_expectation": ""}))
        raise AssertionError("unknown prompt")
    return fn
