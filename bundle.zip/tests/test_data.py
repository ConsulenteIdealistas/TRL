import io
import os
import tempfile
import unittest
import urllib.error
from datetime import date
from pathlib import Path

from tests.helpers import AS_OF, CFG, raw
from trl import http, freshness
from trl.normalize import normalize
from trl.prompts import PromptError, load_prompt, render
from trl.sources import arxiv, pubmed
from trl.store import Store

PUBMED_XML = b"""<?xml version="1.0"?><PubmedArticleSet><PubmedArticle><MedlineCitation><PMID>111</PMID>
<Article><Journal><JournalIssue><PubDate><Year>2026</Year><Month>Oct</Month></PubDate></JournalIssue></Journal>
<ArticleTitle>Gene <i>therapy</i> trial</ArticleTitle><Abstract><AbstractText Label="BACKGROUND">Bg text.</AbstractText>
<AbstractText>Plain.</AbstractText></Abstract></Article><MeshHeadingList><MeshHeading><DescriptorName>Genetic Therapy</DescriptorName></MeshHeading></MeshHeadingList></MedlineCitation>
<PubmedData><ArticleIdList><ArticleId IdType="pubmed">111</ArticleId><ArticleId IdType="doi">10.1/ABC</ArticleId></ArticleIdList></PubmedData></PubmedArticle></PubmedArticleSet>"""
ARXIV_XML = b"""<feed xmlns="http://www.w3.org/2005/Atom" xmlns:arxiv="http://arxiv.org/schemas/atom"><entry>
<id>http://arxiv.org/abs/2610.01234v2</id><published>2026-10-05T10:00:00Z</published><title>Solid  state
 battery</title><summary> Abstract here. </summary><category term="cond-mat.mtrl-sci"/><arxiv:doi>10.1/abc</arxiv:doi></entry></feed>"""


class FreshnessTests(unittest.TestCase):
    def test_parse_and_days(self):
        self.assertEqual(freshness.parse_date("2026-10-10"), date(2026, 10, 10))
        self.assertEqual(freshness.parse_date("2026-10"), date(2026, 10, 1))
        self.assertEqual(freshness.parse_date("2026-10", end=True), date(2026, 10, 31))
        self.assertIsNone(freshness.parse_date("2026-13-01"))
        self.assertIsNone(freshness.parse_date("garbage"))
        self.assertEqual(freshness.days_since("2026-10-10", AS_OF), 10)

    def test_buckets_depend_on_as_of(self):
        self.assertEqual(freshness.freshness_info("2026-10-10", AS_OF)["bucket"], "fresh_30d")
        self.assertEqual(freshness.freshness_info("2026-10-10", date(2027, 6, 1))["bucket"], "older")
        self.assertEqual(freshness.freshness_info("2026-10-25", AS_OF)["bucket"], "future")
        self.assertEqual(freshness.freshness_info(None, AS_OF)["bucket"], "unknown")


class NormalizeTests(unittest.TestCase):
    def test_normalize_ok_and_fatal(self):
        rec, p = normalize(raw(doi="https://doi.org/10.1/ABC"), "t")
        self.assertEqual(rec["keys"][0], "doi:10.1/abc")
        self.assertIsNone(normalize(raw(title="  "), "t")[0])
        self.assertIsNone(normalize({"title": "x"}, "t")[0])
        rec, p = normalize(raw(published="bad"), "t")
        self.assertIsNone(rec["published"])
        self.assertIn("bad_published_date", p)


class SourceParseTests(unittest.TestCase):
    def test_pubmed(self):
        r = pubmed.parse_efetch(PUBMED_XML)[0]
        self.assertEqual((r["pmid"], r["doi"], r["published"]), ("111", "10.1/ABC", "2026-10"))
        self.assertEqual(r["title"], "Gene therapy trial")
        self.assertIn("BACKGROUND: Bg text.", r["abstract"])

    def test_arxiv(self):
        r = arxiv.parse_feed(ARXIV_XML)[0]
        self.assertEqual((r["arxiv_id"], r["published"], r["doi"]), ("2610.01234", "2026-10-05", "10.1/abc"))

    def test_pubmed_fetch_uses_as_of_window(self):
        calls = []

        def fake(url, params=None, **kw):
            calls.append(params)
            return b'{"esearchresult":{"idlist":["111"]}}' if "esearch" in url else PUBMED_XML
        out = pubmed.fetch("q", 5, 30, AS_OF, http=fake, sleep=lambda s: None)
        self.assertEqual(len(out), 1)
        self.assertEqual(calls[0]["maxdate"], "2026/10/20")
        self.assertEqual(calls[0]["mindate"], "2026/09/20")


class DedupeStoreTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / "t.sqlite"
        self.store = Store(self.path)

    def tearDown(self):
        self.store.close()
        self.tmp.cleanup()

    def up(self, **kw):
        rec, _ = normalize(raw(**kw), "t")
        return self.store.upsert_candidate(rec)

    def test_same_id_not_duplicated(self):
        a, n1 = self.up()
        b, n2 = self.up()
        self.assertEqual((a, n1, n2), (b, True, False))
        self.assertEqual(self.store.count_candidates(), 1)

    def test_merge_across_sources_by_doi(self):
        a, _ = self.up(source="pubmed", sid="111", doi="10.1/abc")
        b, new = self.up(source="arxiv", sid="2610.9", doi="https://doi.org/10.1/ABC", title="Different title")
        self.assertEqual(a, b)
        self.assertFalse(new)

    def test_similar_titles_not_merged(self):
        a, _ = self.up(sid="1", title="Same Title")
        b, new = self.up(sid="2", title="Same Title")
        self.assertNotEqual(a, b)
        self.assertTrue(new)

    def test_missing_fields_filled_on_merge(self):
        a, _ = self.up(sid="1", abstract="")
        self.up(sid="1", abstract="now present")
        self.assertEqual(self.store.get_candidate(a)["abstract"], "now present")

    def test_persistence_across_reopen(self):
        a, _ = self.up()
        self.store.upsert_queue(a, "long", "r", ["m"], ["IR"], ["c"], "t", {"x": 1})
        self.store.close()
        self.store = Store(self.path)
        self.assertEqual(self.store.get_candidate(a)["title"], "Paper A")
        q = self.store.list_queue()
        self.assertEqual((len(q), q[0]["missing"], q[0]["next_sources"]), (1, ["m"], ["IR"]))
        self.up()  # 再取得しても増えない
        self.assertEqual(self.store.count_candidates(), 1)
        self.store.resolve_queue(a, "long")
        self.assertEqual(self.store.list_queue(), [])


class PromptTests(unittest.TestCase):
    def test_render(self):
        self.assertEqual(render("a {{x}} b", {"x": "1"}), "a 1 b")
        with self.assertRaises(PromptError):
            render("{{x}} {{y}}", {"x": 1})

    def test_inserted_values_not_reexpanded(self):
        self.assertEqual(render("{{a}}", {"a": "{{b}}", "b": "BAD"}), "{{b}}")

    def test_real_prompts_load_and_have_versions(self):
        for n in ("extract", "long", "event"):
            p = load_prompt(n, CFG["scoring"]["prompts"][n])
            self.assertEqual(len(p["sha"]), 12)


class HttpTests(unittest.TestCase):
    def test_retry_then_success(self):
        seq = [urllib.error.HTTPError("u", 503, "x", {}, None), io.BytesIO(b"ok")]

        def opener(req, timeout):
            r = seq.pop(0)
            if isinstance(r, Exception):
                raise r
            return r
        self.assertEqual(http.fetch("http://x", opener=opener, sleep=lambda s: None), b"ok")

    def test_no_retry_on_4xx_and_error_hides_key(self):
        def opener(req, timeout):
            raise urllib.error.HTTPError(req.full_url, 401, "x", {}, None)
        with self.assertRaises(http.HttpError) as cm:
            http.fetch("http://x/api", params={"api_key": "SECRETSECRET"}, opener=opener, sleep=lambda s: None)
        self.assertNotIn("SECRETSECRET", str(cm.exception))
        self.assertEqual(cm.exception.status, 401)

    def test_gives_up_after_retries(self):
        n = []

        def opener(req, timeout):
            n.append(1)
            raise urllib.error.URLError("down")
        with self.assertRaises(http.HttpError):
            http.fetch("http://x", retries=2, opener=opener, sleep=lambda s: None)
        self.assertEqual(len(n), 3)

    def test_redact_env_secret(self):
        os.environ["ANTHROPIC_API_KEY"] = "sk-abcdef123456"
        try:
            self.assertNotIn("sk-abcdef123456", http.redact("fail sk-abcdef123456 here"))
        finally:
            del os.environ["ANTHROPIC_API_KEY"]


if __name__ == "__main__":
    unittest.main()
