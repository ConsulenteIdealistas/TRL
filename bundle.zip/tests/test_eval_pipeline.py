import json
import tempfile
import unittest
from datetime import date
from pathlib import Path

from tests.helpers import AS_OF, CFG, EVENT_KEYS, LONG_KEYS, assessment, make_llm_fn, raw
from trl import evaluate as ev
from trl.llm import LLMError, Mock, extract_json, Anthropic, Gemini
from trl.pipeline import run_pipeline, screen
from trl.report import build_report
from trl.store import Store


class ValidationTests(unittest.TestCase):
    def test_extract_json(self):
        self.assertEqual(extract_json('```json\n{"a":1}\n```'), {"a": 1})
        for bad in ("", "no json", "{broken", "[1,2]"):
            with self.assertRaises(LLMError):
                extract_json(bad)

    def test_valid_assessment(self):
        s, d, e = ev.validate_assessment(assessment(LONG_KEYS), "long", CFG)
        self.assertEqual(e, [])

    def test_invalid_assessments(self):
        a = assessment(LONG_KEYS)
        del a["items"]["monetization"]
        self.assertIn("missing_item:monetization", ev.validate_assessment(a, "long", CFG)[2])
        a = assessment(LONG_KEYS)
        a["items"]["market_growth"]["evidence"] = []
        self.assertIn("evidence_required:market_growth", ev.validate_assessment(a, "long", CFG)[2])
        a = assessment(LONG_KEYS)
        a["items"]["market_growth"]["reason"] = ""
        self.assertIn("reason_required:market_growth", ev.validate_assessment(a, "long", CFG)[2])
        a = assessment(LONG_KEYS, {"market_growth": None})
        a["items"]["market_growth"]["missing_info"] = []
        self.assertIn("missing_info_required_for_null:market_growth", ev.validate_assessment(a, "long", CFG)[2])
        a = assessment(LONG_KEYS)
        a["items"]["market_growth"]["evidence"][0]["kind"] = "rumor"
        self.assertTrue(any(x.startswith("bad_evidence") for x in ev.validate_assessment(a, "long", CFG)[2]))
        self.assertEqual(ev.validate_assessment({"items": []}, "long", CFG)[2], ["items:must_be_object"])

    def test_extraction_validation(self):
        self.assertTrue(ev.validate_extraction({}))
        self.assertEqual(ev.validate_extraction({"facts": [{"statement": "x"}], "inferences": [], "forecasts": [],
                                                 "hypotheses": [], "counter_points": [], "missing_info": []}), [])


class EvaluateOneTests(unittest.TestCase):
    cand = {"id": "c1", "title": "T", "abstract": "A" * 300, "url": "u", "source": "arxiv",
            "published": "2026-10-10", "fields": []}

    def run_it(self, kind="long", **kw):
        return ev.evaluate_one(self.cand, kind, CFG, Mock(make_llm_fn(**kw)), AS_OF)

    def test_long_final(self):
        r = self.run_it(long_scores={k: 60 for k in LONG_KEYS})
        self.assertEqual((r["status"], r["total"], r["band"]["label"]), ("final", 60.0, "strong"))
        self.assertEqual(set(r["prompt_versions"]), {"extract", "long"})

    def test_long_hold_on_null(self):
        r = self.run_it(long_scores={"monetization": None})
        self.assertEqual((r["status"], r["total"], r["critical_missing"]), ("hold", None, ["monetization"]))

    def test_invalid_ai_response_is_error(self):
        r = self.run_it(bad="not json at all")
        self.assertEqual(r["status"], "error")
        r = self.run_it(long_scores={"monetization": 150})
        self.assertEqual(r["status"], "error")
        self.assertIn("out_of_range:monetization", r["errors"])

    def test_llm_exception_is_contained(self):
        def boom(p):
            raise LLMError("api down")
        r = ev.evaluate_one(self.cand, "long", CFG, Mock(boom), AS_OF)
        self.assertEqual(r["status"], "error")

    def test_event_without_market_expectation_holds(self):
        r = self.run_it("event", event_scores={k: 90 for k in EVENT_KEYS},
                        event={"classification": 4, "market_expectation": ""})
        self.assertEqual(r["status"], "hold")
        self.assertIsNone(r["event"]["classification"])
        self.assertEqual(set(r["critical_missing"]), {"expectation_gap", "not_priced_in"})

    def test_event_with_market_expectation_final(self):
        r = self.run_it("event", event_scores={k: 70 for k in EVENT_KEYS},
                        event={"classification": 4, "market_expectation": "コンセンサスは赤字継続"})
        self.assertEqual((r["status"], r["total"], r["event"]["classification"]), ("final", 70.0, 4))

    def test_provider_requires_key(self):
        import os
        for v in ("ANTHROPIC_API_KEY", "GEMINI_API_KEY"):
            os.environ.pop(v, None)
        with self.assertRaises(LLMError):
            Anthropic()
        with self.assertRaises(LLMError):
            Gemini()

    def test_anthropic_gemini_response_parsing(self):
        import os
        os.environ["ANTHROPIC_API_KEY"] = os.environ["GEMINI_API_KEY"] = "k" * 10
        try:
            a = Anthropic(http=lambda *a, **k: json.dumps({"content": [{"type": "text", "text": "hi"}]}).encode())
            self.assertEqual(a.complete("p"), "hi")
            g = Gemini(http=lambda *a, **k: json.dumps({"candidates": [{"content": {"parts": [{"text": "yo"}]}}]}).encode())
            self.assertEqual(g.complete("p"), "yo")
            bad = Gemini(http=lambda *a, **k: b"{}")
            with self.assertRaises(LLMError):
                bad.complete("p")
        finally:
            del os.environ["ANTHROPIC_API_KEY"], os.environ["GEMINI_API_KEY"]


class ScreenTests(unittest.TestCase):
    def c(self, **kw):
        d = {"published": "2026-10-10", "abstract": "A" * 300}
        d.update(kw)
        return d

    def test_screen(self):
        self.assertIsNone(screen(self.c(), AS_OF, CFG))
        self.assertEqual(screen(self.c(published=None), AS_OF, CFG), "no_published_date")
        self.assertEqual(screen(self.c(published="2026-10-25"), AS_OF, CFG), "published_after_as_of")
        self.assertEqual(screen(self.c(published="2026-10"), date(2026, 10, 15), CFG), "published_after_as_of")  # 月末まで未確定
        self.assertEqual(screen(self.c(published="2024-01-01"), AS_OF, CFG), "stale")
        self.assertEqual(screen(self.c(abstract="short"), AS_OF, CFG), "abstract_too_short")


class IntegrationTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / "d" / "trl.sqlite"

    def tearDown(self):
        self.tmp.cleanup()

    def fetchers(self, fail_pubmed=False):
        def arx(q, n, days, as_of):
            return [raw(sid="2610.0001", doi="10.1/a"), raw(sid="2610.0002", title="B"),
                    raw(sid="2610.0003", title="Short", abstract="x"), {"title": "", "source": "arxiv"}]

        def pm(q, n, days, as_of):
            if fail_pubmed:
                raise RuntimeError("HTTP 500 for http://x?api_key=SECRETSECRET")
            return [raw(source="pubmed", sid="9", doi="10.1/a", title="Same paper via pubmed")]
        return {"arxiv": arx, "pubmed": pm}

    def cfg(self):
        c = dict(CFG)
        c["sources"] = {"defaults": {"max_results": 5, "lookback_days": 30},
                        "queries": [{"name": "q", "arxiv": "a", "pubmed": "p"}]}
        return c

    def test_end_to_end_and_rerun_idempotent(self):
        store = Store(self.path)
        llm = Mock(make_llm_fn(long_scores={"monetization": None}))
        r1 = run_pipeline(store, self.cfg(), llm, as_of=AS_OF, kinds=("long",), fetchers=self.fetchers(),
                          today=AS_OF, log=lambda *_: None)
        c = r1["counts"]
        self.assertEqual((c["fetched"], c["invalid"], c["sources_ok"]), (5, 1, 2))
        self.assertEqual(store.count_candidates(), 2 + 1)  # A(doi統合) , B , Short
        self.assertEqual((c["rejected"], c["screened"]), (1, 2))
        self.assertEqual((c["hold"], c["final"]), (2, 0))
        q = store.list_queue()
        self.assertEqual(len(q), 2)
        self.assertIn("monetization", q[0]["reason"])
        ev1 = store.evaluations_for_run(r1["run_id"], "long")[0]
        self.assertEqual(json.loads(ev1["prompt_versions_json"])["long"]["version"], "v1")
        self.assertEqual(ev1["config_version"], CFG["config_version"])
        store.close()

        # 再実行: 候補は増えず、保留は再評価間隔内なので再評価されない。キューは残る
        store = Store(self.path)
        r2 = run_pipeline(store, self.cfg(), llm, as_of=AS_OF, kinds=("long",), fetchers=self.fetchers(),
                          today=AS_OF, log=lambda *_: None)
        self.assertEqual(store.count_candidates(), 3)
        self.assertEqual(r2["counts"]["new"], 0)
        self.assertEqual(r2["counts"]["selected"], 0)
        self.assertEqual(len(store.list_queue()), 2)

        # 間隔経過後に情報が揃えば確定し、キューは解消
        later = date(2026, 11, 20)
        llm2 = Mock(make_llm_fn(long_scores={k: 65 for k in LONG_KEYS}))
        r3 = run_pipeline(store, self.cfg(), llm2, as_of=AS_OF, kinds=("long",), do_collect=False, today=later,
                          log=lambda *_: None)
        self.assertEqual(r3["counts"]["final"], 2)
        self.assertEqual(store.list_queue(), [])
        text = build_report(store, r3["run_id"])
        self.assertIn("65.0", text)
        self.assertIn("投資利益率ではありません", text)
        store.close()

    def test_source_failure_isolated_and_secret_redacted(self):
        store = Store(self.path)
        logs = []
        r = run_pipeline(store, self.cfg(), None, as_of=AS_OF, fetchers=self.fetchers(fail_pubmed=True),
                         today=AS_OF, log=logs.append)
        self.assertEqual((r["counts"]["sources_ok"], r["counts"]["sources_failed"], r["failed"]), (1, 1, False))
        self.assertFalse(any("SECRETSECRET" in str(x) for x in logs))
        srcs = {s["source"]: s for s in store.run_sources(r["run_id"])}
        self.assertEqual(srcs["pubmed"]["ok"], 0)
        self.assertNotIn("SECRETSECRET", srcs["pubmed"]["error"])
        self.assertEqual(srcs["arxiv"]["ok"], 1)
        self.assertGreater(r["counts"]["skipped_no_llm"], 0)  # LLM未設定 → 評価せず収集のみ

    def test_all_sources_failed_flag(self):
        store = Store(self.path)

        def boom(*a):
            raise RuntimeError("down")
        r = run_pipeline(store, self.cfg(), None, as_of=AS_OF, fetchers={"arxiv": boom, "pubmed": boom},
                         today=AS_OF, log=lambda *_: None)
        self.assertTrue(r["failed"])

    def test_both_kinds_independent_with_shared_extraction(self):
        store = Store(self.path)
        n = {"extract": 0}
        base = make_llm_fn(long_scores={k: 70 for k in LONG_KEYS}, event_scores={k: 50 for k in EVENT_KEYS},
                           event={"classification": 2, "market_expectation": "x"})

        def fn(p):
            if "根拠抽出」担当" in p:
                n["extract"] += 1
            return base(p)
        r = run_pipeline(store, self.cfg(), Mock(fn), as_of=AS_OF, kinds=("long", "event"), fetchers=self.fetchers(),
                         today=AS_OF, log=lambda *_: None)
        self.assertEqual(n["extract"], 2)  # 候補2件、抽出は候補ごとに1回
        self.assertEqual(r["counts"]["final"], 4)
        totals = {(e["kind"], e["total"]) for e in store.evaluations_for_run(r["run_id"])}
        self.assertEqual(totals, {("long", 70.0), ("event", 50.0)})  # 平均されない


if __name__ == "__main__":
    unittest.main()
