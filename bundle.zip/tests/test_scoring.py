import unittest

from tests.helpers import CFG, LONG_KEYS, EVENT_KEYS
from trl import scoring
from trl.config import ConfigError, validate_config
import copy


class ScoringTests(unittest.TestCase):
    def test_weights_sum_100(self):
        for k in ("long", "event"):
            self.assertEqual(sum(CFG["scoring"][k]["weights"].values()), 100)

    def test_bad_weights_rejected(self):
        bad = copy.deepcopy(CFG)
        bad["scoring"]["long"]["weights"]["monetization"] = 30
        with self.assertRaises(ConfigError):
            validate_config(bad)

    def test_total_computation(self):
        items = {k: 80 for k in LONG_KEYS}
        r = scoring.compute(items, "long", CFG)
        self.assertEqual((r["status"], r["total"]), ("final", 80.0))
        items = {"technology_readiness": 100, "technological_advantage": 0, "monetization": 0,
                 "market_growth": 0, "financial_sustainability": 0, "moat_durability": 0}
        self.assertEqual(scoring.compute(items, "long", CFG)["total"], 25.0)

    def test_null_means_hold_no_redistribution(self):
        items = {k: 90 for k in LONG_KEYS}
        items["monetization"] = None
        r = scoring.compute(items, "long", CFG)
        self.assertEqual(r["status"], "hold")
        self.assertIsNone(r["total"])
        self.assertEqual(r["critical_missing"], ["monetization"])

    def test_event_hold_on_critical_missing(self):
        items = {k: 60 for k in EVENT_KEYS}
        items["not_priced_in"] = None
        r = scoring.compute(items, "event", CFG)
        self.assertEqual((r["status"], r["critical_missing"]), ("hold", ["not_priced_in"]))

    def test_range_validation(self):
        for bad in (-1, 100.5, "80", True, float("nan")):
            items = {k: 50 for k in LONG_KEYS}
            items["market_growth"] = bad
            self.assertEqual(scoring.compute(items, "long", CFG)["status"], "error", bad)
        items = {k: 0 for k in LONG_KEYS}
        self.assertEqual(scoring.compute(items, "long", CFG)["total"], 0.0)
        items = {k: 100 for k in LONG_KEYS}
        self.assertEqual(scoring.compute(items, "long", CFG)["total"], 100.0)

    def test_required_items_validated(self):
        items = {k: 50 for k in LONG_KEYS}
        del items["monetization"]
        self.assertIn("missing_item:monetization", scoring.validate_items(items, "long", CFG))
        items = {k: 50 for k in LONG_KEYS}
        items["bogus"] = 1
        self.assertIn("unknown_item:bogus", scoring.validate_items(items, "long", CFG))

    def test_bands(self):
        exp = [(0, "extremely_weak"), (19, "extremely_weak"), (20, "weak"), (39, "weak"), (40, "moderate_uncertain"),
               (59, "moderate_uncertain"), (59.5, "moderate_uncertain"), (60, "strong"), (79, "strong"),
               (80, "very_strong"), (100, "very_strong")]
        for s, label in exp:
            self.assertEqual(scoring.band_for(s, CFG)["label"], label, s)

    def test_long_and_event_not_averaged(self):
        # 2系統の結果は別々に返り、合成関数は存在しない
        self.assertFalse(hasattr(scoring, "combine"))


if __name__ == "__main__":
    unittest.main()
