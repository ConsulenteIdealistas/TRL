import argparse
import os
import sys
from datetime import date, datetime, timezone
from pathlib import Path

from .config import load_config
from .freshness import parse_date
from .llm import LLMError, get_provider
from .pipeline import run_pipeline
from .report import build_report
from .store import Store


def _prune(d, keep=30):
    files = sorted(p for p in d.glob("2*.md"))
    for p in files[:-keep]:
        p.unlink()


def main(argv=None):
    ap = argparse.ArgumentParser(prog="trl")
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("run")
    r.add_argument("--data-dir", default="data")
    r.add_argument("--as-of")
    r.add_argument("--sources", default="pubmed,arxiv")
    r.add_argument("--kinds", default="long")
    r.add_argument("--max-eval", type=int)
    r.add_argument("--llm", default=os.environ.get("TRL_LLM_PROVIDER") or "none")
    r.add_argument("--model")
    r.add_argument("--skip-collect", action="store_true")
    q = sub.add_parser("queue")
    q.add_argument("--data-dir", default="data")
    sub.add_parser("check-config")
    a = ap.parse_args(argv)
    cfg = load_config()
    if a.cmd == "check-config":
        print(f"OK config={cfg['config_version']} hash={cfg['config_hash']}")
        return 0
    store = Store(Path(a.data_dir) / "trl.sqlite")
    if a.cmd == "queue":
        for x in store.list_queue():
            print(f"[{x['kind']}] {x['title']}\n  {x['reason']}")
        return 0
    as_of = parse_date(a.as_of) if a.as_of else datetime.now(timezone.utc).date()
    if as_of is None:
        print("invalid --as-of (YYYY-MM-DD)")
        return 2
    kinds = [k for k in a.kinds.split(",") if k]
    sources = [s for s in a.sources.split(",") if s]
    if not set(kinds) <= {"long", "event"} or not set(sources) <= {"pubmed", "arxiv"}:
        print("invalid --kinds or --sources")
        return 2
    try:
        llm = get_provider(a.llm, a.model)
    except LLMError as e:
        print(f"::error::{e}")
        return 2
    res = run_pipeline(store, cfg, llm, as_of=as_of, sources=sources, kinds=kinds, max_eval=a.max_eval,
                       do_collect=not a.skip_collect)
    text = build_report(store, res["run_id"])
    rep = Path(a.data_dir) / "reports"
    rep.mkdir(parents=True, exist_ok=True)
    (rep / f"{res['run_id']}.md").write_text(text, encoding="utf-8")
    (rep / "latest.md").write_text(text, encoding="utf-8")
    _prune(rep)
    if os.environ.get("GITHUB_STEP_SUMMARY"):
        with open(os.environ["GITHUB_STEP_SUMMARY"], "a", encoding="utf-8") as f:
            f.write(text)
    store.close()
    print(f"[done] {res['counts']}")
    return 1 if res["failed"] else 0


if __name__ == "__main__":
    sys.exit(main())
