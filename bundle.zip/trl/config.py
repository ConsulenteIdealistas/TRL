"""設定の読み込みと検証。設定ファイルのハッシュを実行ごとに記録する。"""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


class ConfigError(ValueError):
    pass


def validate_config(cfg):
    sc = cfg["scoring"]
    for kind in ("long", "event"):
        sec = sc.get(kind)
        if not sec:
            raise ConfigError(f"missing section: {kind}")
        w = sec["weights"]
        if any((not isinstance(v, (int, float))) or v <= 0 for v in w.values()):
            raise ConfigError(f"{kind}: weights must be positive numbers")
        if abs(sum(w.values()) - 100) > 1e-9:
            raise ConfigError(f"{kind}: weights must sum to 100 (got {sum(w.values())})")
        for r in sec["required"]:
            if r not in w:
                raise ConfigError(f"{kind}: required item {r} not in weights")
    bands = sc["bands"]
    if bands[0]["min"] != 0 or bands[-1]["max"] != 100:
        raise ConfigError("bands must cover 0..100")
    for a, b in zip(bands, bands[1:]):
        if b["min"] != a["max"] + 1:
            raise ConfigError("bands must be contiguous")


def load_config(config_dir=None):
    d = Path(config_dir) if config_dir else ROOT / "config"
    raw, h = {}, hashlib.sha256()
    for name in ("scoring", "sources"):
        text = (d / f"{name}.json").read_text(encoding="utf-8-sig")
        h.update(text.encode("utf-8"))
        raw[name] = json.loads(text)
    cfg = {
        "scoring": raw["scoring"],
        "sources": raw["sources"],
        "config_version": raw["scoring"]["config_version"],
        "config_hash": h.hexdigest()[:16],
    }
    validate_config(cfg)
    return cfg
