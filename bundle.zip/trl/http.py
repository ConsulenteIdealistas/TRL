"""HTTP取得(リトライ・秘密情報のマスク付き)。標準ライブラリのみ。"""
import os
import re
import time
import urllib.error
import urllib.parse
import urllib.request

SECRET_ENV = ("ANTHROPIC_API_KEY", "GEMINI_API_KEY", "NCBI_API_KEY", "GITHUB_TOKEN", "GH_TOKEN", "TOKEN")
_PARAM_RE = re.compile(r"(?i)(api[_-]?key|key|token)=([^&\s]+)")


def redact(text):
    text = str(text)
    for name in SECRET_ENV:
        v = os.environ.get(name)
        if v and len(v) >= 6:
            text = text.replace(v, "***")
    return _PARAM_RE.sub(lambda m: m.group(1) + "=***", text)


class HttpError(Exception):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


def fetch(url, params=None, headers=None, data=None, timeout=30, retries=3,
          backoff=2.0, opener=None, sleep=time.sleep):
    opener = opener or urllib.request.urlopen
    full = url + ("?" + urllib.parse.urlencode(params) if params else "")
    hdrs = {"User-Agent": "trl-analysis/0.1"}
    hdrs.update(headers or {})
    attempt = 0
    while True:
        req = urllib.request.Request(full, data=data, headers=hdrs)
        try:
            with opener(req, timeout=timeout) as resp:
                return resp.read()
        except urllib.error.HTTPError as e:
            status, retryable, msg = e.code, (e.code == 429 or e.code >= 500), f"HTTP {e.code}"
        except (urllib.error.URLError, TimeoutError, ConnectionError) as e:
            status, retryable, msg = None, True, f"network error: {type(e).__name__}"
        attempt += 1
        if not retryable or attempt > retries:
            # URLのクエリ(APIキーが入り得る)はメッセージに含めない
            raise HttpError(redact(f"{msg} for {url}"), status)
        sleep(backoff ** attempt)
