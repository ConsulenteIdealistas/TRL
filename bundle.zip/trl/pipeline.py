"""処理フロー: 収集 → 正規化 → 重複排除 → 検証 → スクリーニング → 評価 → 保存。"""
import time
import uuid
from datetime import date, datetime, timedelta, timezone

from . import evaluate as ev
from .freshness import days_since, parse_date
from .http import redact
from .normalize import normalize
from .sources import arxiv, pubmed

DEFAULT_FETCHERS = {"pubmed": pubmed.fetch, "arxiv": arxiv.fetch}


def new_run_id(now=None):
    now = now or datetime.now(timezone.utc)
    return now.strftime("%Y%m%dT%H%M%SZ") + "-" + uuid.uuid4().hex[:6]


def screen(cand, as_of, cfg):
    """合格なら None、不合格なら理由。as_of より後の資料は事前評価に混入させない。"""
    sc = cfg["scoring"]["screening"]
    if not cand["published"]:
        return "no_published_date"
    end = parse_date(cand["published"], end=True)
    if end is None or end > as_of:
        return "published_after_as_of"
    if days_since(cand["published"], as_of) > sc["max_age_days"]:
        return "stale"
    if len(cand["abstract"] or "") < sc["min_abstract_chars"]:
        return "abstract_too_short"
    return None


def collect(store, cfg, run_id, as_of, sources, fetchers, counts, log):
    d = cfg["sources"]["defaults"]
    now = datetime.now(timezone.utc).isoformat(timespec="seconds")
    for q in cfg["sources"]["queries"]:
        for sname in sources:
            qs = q.get(sname)
            if not qs:
                continue
            t0, fetched, new, dups, invalid, err = time.monotonic(), 0, 0, 0, 0, None
            try:
                raws = fetchers[sname](qs, q.get("max_results", d["max_results"]),
                                       q.get("lookback_days", d["lookback_days"]), as_of)
                fetched = len(raws)
                for raw in raws:
                    rec, problems = normalize(raw, now)
                    if rec is None:
                        invalid += 1
                        continue
                    _, is_new = store.upsert_candidate(rec, run_id)
                    new += is_new
                    dups += (not is_new)
            except Exception as e:
                err = redact(f"{type(e).__name__}: {e}")[:300]
                log(f"::warning::source {sname} / {q['name']} failed: {err}")
            store.add_run_source(run_id, sname, q["name"], fetched, new, dups, invalid, err is None, err,
                                 time.monotonic() - t0)
            for k, v in (("fetched", fetched), ("new", new), ("duplicates", dups), ("invalid", invalid)):
                counts[k] += v
            counts["sources_ok" if err is None else "sources_failed"] += 1
            log(f"[collect] {sname}/{q['name']}: fetched={fetched} new={new} dup={dups} invalid={invalid}"
                + (f" ERROR={err}" if err else ""))


def select_for_eval(store, cfg, today, limit):
    sc = cfg["scoring"]["screening"]
    rows = []
    for c in store.list_by_status(["screened", "hold", "error"]):
        if c["status"] == "hold":
            last = parse_date((c["last_eval_at"] or "")[:10])
            if last and (today - last).days < sc["reeval_after_days"]:
                continue
        if c["status"] == "error" and c["retry_count"] >= sc["max_retries"]:
            continue
        rows.append(c)
    rows.sort(key=lambda c: c["published"] or "", reverse=True)
    return rows[:limit]


def _queue_reason(res):
    if res["status"] == "error":
        return "evaluation_error: " + "; ".join(res["errors"][:3])
    crit = ",".join(res["critical_missing"])
    return "missing_items: " + ",".join(res["missing"]) + (f" (critical: {crit})" if crit else "")


def run_pipeline(store, cfg, llm, *, as_of, sources=("pubmed", "arxiv"), kinds=("long",), max_eval=None,
                 do_collect=True, fetchers=None, today=None, log=print, prompt_dir=None):
    t0 = time.monotonic()
    today = today or datetime.now(timezone.utc).date()
    run_id = new_run_id()
    store.start_run(run_id, cfg["config_version"], cfg["config_hash"], as_of.isoformat(),
                    {"sources": list(sources), "kinds": list(kinds), "max_eval": max_eval, "collect": do_collect,
                     "llm": getattr(llm, "name", "none")})
    counts = {k: 0 for k in ("fetched", "new", "duplicates", "invalid", "sources_ok", "sources_failed", "screened",
                             "rejected", "selected", "final", "hold", "error", "skipped_no_llm")}
    log(f"[run] {run_id} as_of={as_of} config={cfg['config_version']}/{cfg['config_hash']}")
    if do_collect:
        collect(store, cfg, run_id, as_of, sources, {**DEFAULT_FETCHERS, **(fetchers or {})}, counts, log)
    for c in store.list_by_status(["new"]):
        reason = screen(c, as_of, cfg)
        store.set_status(c["id"], "rejected" if reason else "screened", reason)
        counts["rejected" if reason else "screened"] += 1
    limit = max_eval if max_eval is not None else cfg["scoring"]["screening"]["max_eval_per_run"]
    selected = select_for_eval(store, cfg, today, limit)
    counts["selected"] = len(selected)
    if selected and llm is None:
        counts["skipped_no_llm"] = len(selected)
        log("[eval] LLMプロバイダ未設定のため評価をスキップ(収集のみ)。TRL_LLM_PROVIDER を設定してください。")
        selected = []
    for c in selected:
        extraction, meta, outcomes = None, None, []
        for kind in kinds:
            res = ev.evaluate_one(c, kind, cfg, llm, as_of, extraction, meta, prompt_dir)
            extraction, meta = res["extraction"], res["prompt_versions"].get("extract")
            store.add_evaluation(run_id, c["id"], res)
            counts[res["status"]] += 1
            outcomes.append(res["status"])
            if res["status"] == "final":
                store.resolve_queue(c["id"], kind)
            else:
                store.upsert_queue(c["id"], kind, _queue_reason(res), res["missing"] or res["errors"],
                                   res["next_sources"], res["reeval_conditions"] or ["追加情報の取得後、または再評価間隔の経過後"],
                                   datetime.now(timezone.utc).isoformat(timespec="seconds"), res["prompt_versions"])
            log(f"[eval] {c['id']} {kind}: {res['status']} total={res['total']}")
        status = "hold" if "hold" in outcomes else ("error" if "error" in outcomes else "evaluated")
        store.set_status(c["id"], status, eval_at=datetime.now(timezone.utc).isoformat(timespec="seconds"),
                         retry_inc=(status == "error"))
    all_failed = do_collect and counts["sources_ok"] == 0 and counts["sources_failed"] > 0
    store.finish_run(run_id, counts, "failed" if all_failed else "ok", time.monotonic() - t0)
    return {"run_id": run_id, "counts": counts, "failed": all_failed}
