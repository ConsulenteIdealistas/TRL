"""SQLite による永続化。重複排除は identifiers テーブルの安定IDで行う。"""
import hashlib
import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS candidates(
  id TEXT PRIMARY KEY, title TEXT, abstract TEXT, url TEXT, source TEXT, source_id TEXT,
  doi TEXT, published TEXT, retrieved_at TEXT, fields_json TEXT, info_type TEXT,
  status TEXT NOT NULL DEFAULT 'new', screen_reason TEXT, last_eval_at TEXT,
  retry_count INTEGER NOT NULL DEFAULT 0, first_seen_run TEXT);
CREATE TABLE IF NOT EXISTS identifiers(key TEXT PRIMARY KEY, candidate_id TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS evaluations(
  id INTEGER PRIMARY KEY AUTOINCREMENT, run_id TEXT, candidate_id TEXT, kind TEXT, as_of TEXT,
  evaluated_at TEXT, status TEXT, total REAL, band TEXT, items_json TEXT, extraction_json TEXT,
  event_json TEXT, prompt_versions_json TEXT, config_version TEXT, config_hash TEXT,
  llm_provider TEXT, llm_model TEXT, input_hash TEXT, errors_json TEXT);
CREATE TABLE IF NOT EXISTS review_queue(
  candidate_id TEXT, kind TEXT, reason TEXT, missing_json TEXT, next_sources_json TEXT,
  reeval_conditions_json TEXT, last_eval_at TEXT, versions_json TEXT, created_at TEXT,
  updated_at TEXT, resolved_at TEXT, PRIMARY KEY(candidate_id, kind));
CREATE TABLE IF NOT EXISTS runs(
  run_id TEXT PRIMARY KEY, started_at TEXT, finished_at TEXT, config_version TEXT, config_hash TEXT,
  as_of TEXT, params_json TEXT, counts_json TEXT, status TEXT, duration_sec REAL);
CREATE TABLE IF NOT EXISTS run_sources(
  run_id TEXT, source TEXT, query TEXT, fetched INTEGER, new INTEGER, duplicates INTEGER,
  invalid INTEGER, ok INTEGER, error TEXT, seconds REAL);
"""


def now_iso():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _j(x):
    return json.dumps(x, ensure_ascii=False, sort_keys=True)


class Store:
    def __init__(self, path):
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(str(path))
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA journal_mode=DELETE")  # -wal/-shm を作らない(コミット対象を1ファイルに)
        self.conn.executescript(SCHEMA)

    def close(self):
        self.conn.commit()
        self.conn.close()

    # --- candidates ---
    def upsert_candidate(self, rec, run_id=None):
        """-> (candidate_id, is_new)。既存IDに一致すれば統合し、欠けた項目だけ補う。"""
        c = self.conn
        existing = None
        for k in rec["keys"]:
            row = c.execute("SELECT candidate_id FROM identifiers WHERE key=?", (k,)).fetchone()
            if row:
                existing = row[0]
                break
        if existing:
            for k in rec["keys"]:
                c.execute("INSERT OR IGNORE INTO identifiers VALUES(?,?)", (k, existing))
            cur = self.get_candidate(existing)
            if not cur["abstract"] and rec["abstract"]:
                c.execute("UPDATE candidates SET abstract=? WHERE id=?", (rec["abstract"], existing))
            if not cur["doi"] and rec.get("doi"):
                c.execute("UPDATE candidates SET doi=? WHERE id=?", (rec["doi"], existing))
            c.commit()
            return existing, False
        cid = "c_" + hashlib.sha1(rec["keys"][0].encode()).hexdigest()[:12]
        c.execute(
            "INSERT INTO candidates(id,title,abstract,url,source,source_id,doi,published,retrieved_at,"
            "fields_json,info_type,status,first_seen_run) VALUES(?,?,?,?,?,?,?,?,?,?,?,'new',?)",
            (cid, rec["title"], rec["abstract"], rec["url"], rec["source"], rec["source_id"], rec.get("doi"),
             rec["published"], rec["retrieved_at"], _j(rec["fields"]), rec["info_type"], run_id))
        for k in rec["keys"]:
            c.execute("INSERT OR IGNORE INTO identifiers VALUES(?,?)", (k, cid))
        c.commit()
        return cid, True

    def get_candidate(self, cid):
        row = self.conn.execute("SELECT * FROM candidates WHERE id=?", (cid,)).fetchone()
        if not row:
            return None
        d = dict(row)
        d["fields"] = json.loads(d.pop("fields_json") or "[]")
        return d

    def list_by_status(self, statuses):
        q = ",".join("?" * len(statuses))
        rows = self.conn.execute(f"SELECT id FROM candidates WHERE status IN ({q})", statuses).fetchall()
        return [self.get_candidate(r[0]) for r in rows]

    def set_status(self, cid, status, reason=None, eval_at=None, retry_inc=False):
        self.conn.execute(
            "UPDATE candidates SET status=?, screen_reason=COALESCE(?,screen_reason), "
            "last_eval_at=COALESCE(?,last_eval_at), retry_count=retry_count+? WHERE id=?",
            (status, reason, eval_at, 1 if retry_inc else 0, cid))
        self.conn.commit()

    def count_candidates(self):
        return self.conn.execute("SELECT COUNT(*) FROM candidates").fetchone()[0]

    # --- evaluations ---
    def add_evaluation(self, run_id, cid, ev):
        cur = self.conn.execute(
            "INSERT INTO evaluations(run_id,candidate_id,kind,as_of,evaluated_at,status,total,band,items_json,"
            "extraction_json,event_json,prompt_versions_json,config_version,config_hash,llm_provider,llm_model,"
            "input_hash,errors_json) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (run_id, cid, ev["kind"], ev["as_of"], now_iso(), ev["status"], ev["total"],
             (ev["band"] or {}).get("label"), _j(ev["items"]), _j(ev.get("extraction")), _j(ev.get("event")),
             _j(ev["prompt_versions"]), ev["config_version"], ev["config_hash"], ev["llm_provider"],
             ev["llm_model"], ev["input_hash"], _j(ev["errors"])))
        self.conn.commit()
        return cur.lastrowid

    def latest_evaluation(self, cid, kind):
        row = self.conn.execute(
            "SELECT * FROM evaluations WHERE candidate_id=? AND kind=? ORDER BY id DESC LIMIT 1",
            (cid, kind)).fetchone()
        return dict(row) if row else None

    def evaluations_for_run(self, run_id, kind=None):
        q = "SELECT e.*, c.title, c.url FROM evaluations e JOIN candidates c ON c.id=e.candidate_id WHERE run_id=?"
        args = [run_id]
        if kind:
            q += " AND kind=?"
            args.append(kind)
        return [dict(r) for r in self.conn.execute(q, args).fetchall()]

    # --- review queue ---
    def upsert_queue(self, cid, kind, reason, missing, next_sources, reeval, last_eval_at, versions):
        now = now_iso()
        self.conn.execute(
            "INSERT INTO review_queue(candidate_id,kind,reason,missing_json,next_sources_json,"
            "reeval_conditions_json,last_eval_at,versions_json,created_at,updated_at,resolved_at) "
            "VALUES(?,?,?,?,?,?,?,?,?,?,NULL) ON CONFLICT(candidate_id,kind) DO UPDATE SET "
            "reason=excluded.reason, missing_json=excluded.missing_json, "
            "next_sources_json=excluded.next_sources_json, reeval_conditions_json=excluded.reeval_conditions_json, "
            "last_eval_at=excluded.last_eval_at, versions_json=excluded.versions_json, "
            "updated_at=excluded.updated_at, resolved_at=NULL",
            (cid, kind, reason, _j(missing), _j(next_sources), _j(reeval), last_eval_at, _j(versions), now, now))
        self.conn.commit()

    def resolve_queue(self, cid, kind):
        self.conn.execute("UPDATE review_queue SET resolved_at=? WHERE candidate_id=? AND kind=? AND resolved_at IS NULL",
                          (now_iso(), cid, kind))
        self.conn.commit()

    def list_queue(self, open_only=True):
        q = ("SELECT r.*, c.title, c.url FROM review_queue r JOIN candidates c ON c.id=r.candidate_id"
             + (" WHERE r.resolved_at IS NULL" if open_only else "") + " ORDER BY r.updated_at DESC")
        out = []
        for r in self.conn.execute(q).fetchall():
            d = dict(r)
            for k in ("missing_json", "next_sources_json", "reeval_conditions_json", "versions_json"):
                d[k[:-5]] = json.loads(d.pop(k) or "null")
            out.append(d)
        return out

    # --- runs ---
    def start_run(self, run_id, config_version, config_hash, as_of, params):
        self.conn.execute("INSERT INTO runs(run_id,started_at,config_version,config_hash,as_of,params_json,status) "
                          "VALUES(?,?,?,?,?,?,'running')", (run_id, now_iso(), config_version, config_hash, as_of, _j(params)))
        self.conn.commit()

    def finish_run(self, run_id, counts, status, duration):
        self.conn.execute("UPDATE runs SET finished_at=?, counts_json=?, status=?, duration_sec=? WHERE run_id=?",
                          (now_iso(), _j(counts), status, round(duration, 2), run_id))
        self.conn.commit()

    def add_run_source(self, run_id, source, query, fetched, new, dups, invalid, ok, error, seconds):
        self.conn.execute("INSERT INTO run_sources VALUES(?,?,?,?,?,?,?,?,?,?)",
                          (run_id, source, query, fetched, new, dups, invalid, 1 if ok else 0, error, round(seconds, 2)))
        self.conn.commit()

    def get_run(self, run_id):
        r = self.conn.execute("SELECT * FROM runs WHERE run_id=?", (run_id,)).fetchone()
        return dict(r) if r else None

    def run_sources(self, run_id):
        return [dict(r) for r in self.conn.execute("SELECT * FROM run_sources WHERE run_id=?", (run_id,)).fetchall()]
